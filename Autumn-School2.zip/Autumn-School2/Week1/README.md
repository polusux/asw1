# Make your First App - Dice Roller 

This is the toy app for lesson 1

## Dice Roller

Dice Roller is a simple app that rolls a six sided die.


## Screenshots

![Screenshot1](screenshots/screen0.png) ![Screenshot1](screenshots/screen1.png)

<br><br>
*This app is from [udacity course](https://classroom.udacity.com/courses/ud9012)*
